
# :warning: Driver must be in PATH
Make sure that your driver must be included in **PATH** or else the script will fail to run.
## Must have chrome version 94
If not, then delete the file named chromedriver.exe and download the apt chrome driver from https://sites.google.com/chromium.org/driver/downloads?authuser=0. Then add the driver to **PATH**
