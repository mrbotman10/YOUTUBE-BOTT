# :warning: Driver must be in PATH
Make sure that your driver must be included in **PATH** or else the script will fail to run. I have provided the Web Driver for FireFox (geckodriver.exe). Just add it to the **PATH** and Bob's your uncle.
